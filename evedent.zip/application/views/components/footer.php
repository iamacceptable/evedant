<!-- /Body -->
    <a href="#" class="scroll_to_top icon-up-2" title="Scroll to top"></a>
    <div class="custom_html_section"></div>
		
	<script type="text/javascript" src="<?= base_url();?>assets/js/jquery/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="<?= base_url();?>assets/js/infiniteslidev2.js"></script>
    <script type="text/javascript">
        $(function(){
            $('.slidy-op').infiniteslide({
                  'speed': 50
            });
        });
    </script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/jquery-migrate.min.js"></script>	
	<script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/core.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/widget.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/tabs.min.js"></script>
	<script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/accordion.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/effect.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/ui/effect-fade.min.js"></script>
	<script type="text/javascript" src="<?= base_url();?>assets/js/jquery/jquery.blockUI.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery/jquery.cookie.min.js"></script>
	
	<script type="text/javascript" src="<?= base_url();?>assets/js/global.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/core.utils.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/core.init.min.js"></script>	
    <script type="text/javascript" src="<?= base_url();?>assets/js/shortcodes/shortcodes.min.js"></script>	
	
    <script type="text/javascript" src="<?= base_url();?>assets/js/rs-plugin/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/rs-plugin/jquery.themepunch.revolution.min.js"></script> 
	<script type="text/javascript" src="<?= base_url();?>assets/js/slider_init.js"></script>

    <script type="text/javascript" src="<?= base_url();?>assets/js/superfish.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/jquery.slidemenu.min.js"></script>

    <script type="text/javascript" src="<?= base_url();?>assets/js/mediaelement/mediaelement-and-player.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/mediaelement/wp-mediaelement.min.js"></script>

    <script type="text/javascript" src="<?= base_url();?>assets/js/core.messages/core.messages.min.js"></script>
    
	<script type="text/javascript" src="<?= base_url();?>assets/js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="<?= base_url();?>assets/js/hover/jquery.hoverdir.min.js"></script>
	<script type="text/javascript" src="<?= base_url();?>assets/js/prettyPhoto/jquery.prettyPhoto.min.js"></script>		
    <script type="text/javascript" src="<?= base_url();?>assets/js/swiper/idangerous.swiper-2.7.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/swiper/idangerous.swiper.scrollbar-2.4.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/diagram/chart.min.js"></script>
    
</body>

</html>