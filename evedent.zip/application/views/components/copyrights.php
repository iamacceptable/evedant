<div class="copyright_wrap">
    <div class="content_wrap">
        <p>EVEDANT © 2020 | All Rights Reserved | Developed by: <a href="https://www.linkedin.com/in/iamacceptable">Shubham Kumar</a></p>
    </div>
</div>