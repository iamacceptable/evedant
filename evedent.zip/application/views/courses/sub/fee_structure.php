<tr>
  	<td><?= "₹ ".$courseRegistrationFees."/-"; ?></td>
  	<td><?= "₹ ".$courseTuitionFees."/-"; ?></td>
  	<td><?= "₹ ".$courseStudyMaterialFees."/-"; ?></td>
  	<td><?= "18% GST of Tuition Fees"; ?></td>
</tr>