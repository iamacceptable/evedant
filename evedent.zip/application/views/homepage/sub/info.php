<div class="sc_section" data-animation="animated fadeInUp normal">
	<div class="sc_content content_wrap  margin_top_2_5em_imp margin_bottom_2_5em_imp">
		<div class="sc_infobox sc_infobox_style_info sc_infobox sc_infobox_iconed icon-info-2 inited text_center" >Join online classes from anywhere in India | No Fee for ONLINE Classes*</div>
		<a href="<?= base_url();?>Contact_US" class="sc_button sc_button_square sc_button_style_filled sc_button_bg_link sc_button_size_small alignleft sc_buttons_st1 sc_buttons_st5">Contact Us For More Details!</a>
		<a href="<?= base_url();?>Registration" class="sc_button sc_button_square sc_button_style_filled sc_button_bg_link sc_button_size_small alignleft sc_buttons_st1 sc_buttons_st5">Register Now!</a>
	</div>
</div>