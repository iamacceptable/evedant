<li data-transition="random" data-slotamount="7" data-masterspeed="300" data-saveperformance="off">
    <img src="<?= base_url();?>assets/images/green.jpg" alt="green" data-bgposition="center top" data-bgfit="normal" data-bgrepeat="repeat">
    <!-- <img src="<?= base_url()."assets/images/banner_pic2.jpg"; ?>" alt="green" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> -->
    <div class="tp-caption customin stl cust-z-index-5 rs-cust-style8" data-x="20" data-y="230" data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:20;transformOrigin:50% 100%;" data-speed="1300" data-start="500" data-easing="Power3.easeInOut" data-elementdelay="0.1" data-endelementdelay="0.1" > <!-- golu -->
		<img class="rounded_tiny shadow_lg" src="<?= base_url()."assets/images/uploads/homepage/carousel/".$carouselPicture; ?>" alt="">
    </div>
     <div class="tp-caption title sfr stl tp-resizeme cust-z-index-6 rs-cust-style1" data-x="570" data-y="190" data-speed="500" data-start="1350" data-easing="Power3.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.1" data-endelementdelay="0.1" >
        <?= $carouselHeadline; ?>
    </div>
    <div class="tp-caption slide_text sfr stl tp-resizeme cust-z-index-7 rs-cust-style2" data-x="570" data-y="380" data-speed="500" data-start="1750" data-easing="Power3.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.1" data-endelementdelay="0.1" >
		<span class="font-w_400"><?= $carouselTagline; ?></span>
    </div>
    <div class="tp-caption slide_button customin stl tp-resizeme cust-z-index-8 rs-cust-style3" data-x="570" data-y="460" data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:-20;transformOrigin:50% 0%;" data-speed="500" data-start="2200" data-easing="Power3.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.1" data-endelementdelay="0.1">
		<a href="<?= base_url();?>Registration" class="slide_button_white">Register Now</a>
    </div>
</li>