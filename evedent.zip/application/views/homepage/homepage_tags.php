<!-- <div class="sc_section" data-animation="animated zoomIn normal">
	<h1>Slick Marquee Test</h1>
<div class="slick marquee">
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
  <div class="slick-slide">
    <div class="inner">
      <img src="http://placehold.it/179x78/273640/fff/" alt="Placeholder" width="179" height="78"/>
    </div>
  </div>
</div>
</div> -->
<div class="sc_section" data-animation="animated zoomIn normal">
	<div class="sc_content content_wrap margin_top_3em_imp margin_bottom_3em_imp sc_features_st1">
		<div class="columns_wrap sc_columns columns_fluid sc_columns_count_3">
			<div class="column-1_3 sc_column_item sc_column_item_1 odd first text_center">
				<a class="sc_icon icon-woman-2 sc_icon_bg_menu menu_dark_color font_5em lh_1em"></a>
				<div class="sc_section font-w_400 margin_top_1em_imp">
					<p>
						<a class="menu_color"><?= $tags['firstTag']; ?></a>
					</p>
				</div>
			</div>
			<div class="column-1_3 sc_column_item sc_column_item_2 even text_center">
				<a class="sc_icon icon-rocket-2 sc_icon_bg_menu menu_dark_color font_5em lh_1em"></a>
				<div class="sc_section font-w_400 margin_top_1em_imp">
					<p>
						<a class="menu_color"><?= $tags['secondTag']; ?></a>
					</p>
				</div>
			</div>
			<div class="column-1_3 sc_column_item sc_column_item_3 odd text_center">
				<a class="sc_icon icon-world-2 sc_icon_bg_menu menu_dark_color font_5em lh_1em"></a>
				<div class="sc_section font-w_400 margin_top_1em_imp">
					<p>
						<a class="menu_color"><?= $tags['thirdTag']; ?></a>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>