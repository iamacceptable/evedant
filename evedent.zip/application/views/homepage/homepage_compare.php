<div class="sc_section" data-animation="animated fadeInUp normal">
	<div class="sc_content content_wrap margin_top_2_5em_imp margin_bottom_2_5em_imp">
		<div class="sc_section aligncenter ">
			<h2 class="sc_title sc_title_regular margin_top_0">What makes you to learn with Evedant?</h2>
			<div class="columns_wrap sc_columns columns_fluid sc_columns_count_2">
				<div class="col column-1_2 sc_column_item sc_column_item_1">
					<p><li>Class Room Teaching</li></p>	
					<p><li>Class Room Test Series</li></p>	
					<p><li>Class Room Assignments</li></p>	
					<p><li>Doubt Clearing Sessions</li></p>	
					<p><li>15 Mock Tests based on CBSE Board Examination (3 hour Duration)</li></p>	
				</div>
				<div class="column-1_2 sc_column_item sc_column_item_2">
					<p><li>Additional Problem Solving at Centre</li></p>	
					<p><li>Home Assignments will be given at Centre</li></p>	
					<p><li>Regular Feedbacks and Analysis</li></p>	
					<p><li>Practice Test and Mock Test</li></p>	
					<p><li>Regular Information regarding scholarship and competitive examination</li></p>	
				</div>
			</div>
		</div>
		<!-- <div id="sc_section_4" class="sc_section margin_top_1_5em_imp margin_bottom_0_imp height_75">
			<div id="sc_section_4_scroll" class="sc_scroll sc_scroll_horizontal swiper-slider-container scroll-container height_75">
				<div class="sc_scroll_wrapper swiper-wrapper">
					<div class="sc_scroll_slide swiper-slide">
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp">
							<img src="http://placehold.it/56x60" alt="" />
						</figure>
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp margin_left_4em_imp">
							<img src="http://placehold.it/159x60" alt="" />
						</figure>
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp margin_left_4em_imp">
							<img src="http://placehold.it/83x60" alt="" />
						</figure>
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp margin_left_4em_imp">
							<img src="http://placehold.it/62x60" alt="" />
						</figure>
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp margin_left_4em_imp">
							<img src="http://placehold.it/60x60" alt="" />
						</figure>
						<figure class="sc_image  alignleft sc_image_shape_square margin_right_0_imp margin_left_4em_imp">
							<img src="http://placehold.it/155x60" alt="" />
						</figure>
					</div>
				</div>
				<div id="sc_section_4_scroll_bar" class="sc_scroll_bar sc_scroll_bar_horizontal sc_section_471175375_scroll_bar"></div>
			</div>
		</div> -->
	</div>
</div>