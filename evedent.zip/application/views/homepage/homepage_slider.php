<section class="slider_wrap slider_fullwide slider_engine_revo slider_alias_education_home_slider">
    <div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container">                    
        <div id="rev_slider_1_1" class="rev_slider fullwidthabanner disp_none height_630 max-height_630">
            <ul>
                <?php
                    foreach($carousels as $slide):
                        $this->view('homepage/sub/slide',$slide);
                    endforeach;
                ?>
            </ul>
            <div class="tp-bannertimer"></div>
        </div>
	</div>
    <ul class="slidy-op">
        <li class="icon-alert-2 inited">Congratulations to our Star Performers 2020 (CBSE Board Class 12th) <b>Mihir Srivastava (96%), Aabhas (88%) &amp; Aakanksha (85%).</b></li>
        <li class="icon-alert-2 inited">Congratulations to our Star Performers 2020 (CBSE Board Class 10th) <b>Arpit Singh (95%), Vanshika Pandita (93%), Satvik Shukla (93%), Devanshi Srivastav (91%), Gowdham 89(.7%), Areen Gupta 88(.4%), Taruni Mishra (89%), Suryansh Singh (83%), Archisman Singh (83%), Divyanshu (80%).</b></li>
    </ul>
</section>