<div class="sc_section">
	<div class="sc_content content_wrap margin_top_3em_imp margin_bottom_3em_imp">
		<div class="columns_wrap sc_columns columns_fluid sc_columns_count_3">
			<div class="column-1_4 sc_column_item sc_column_item_1 odd first text_center">
				<a href="mailto:hr@evedant.in">
					<span class="sc_icon icon-mail-2 link_color font_5em lh_1em"></span>
					<div class="sc_section margin_top_1em_imp">
						<p>hr@evedant.in
						</p>
					</div>
				</a>
			</div>
			<div class="column-1_4 sc_column_item sc_column_item_2 even text_center">
				<a href="tel:+91 7678612504">
					<span class="sc_icon icon-telephone-2 link_color font_5em lh_1em"></span>
					<div class="sc_section margin_top_1em_imp sc_features_st1">
						<p>
							+91 7678612504
						</p>
					</div>
				</a>
			</div>
			<div class="column-1_4 sc_column_item sc_column_item_2 even text_center">
				<a href="tel:+91 9811333406">
					<span class="sc_icon icon-telephone-2 link_color font_5em lh_1em"></span>
					<div class="sc_section margin_top_1em_imp sc_features_st1">
						<p>
							+91 9811333406
						</p>
					</div>
				</a>
			</div>
			<div class="column-1_4 sc_column_item sc_column_item_3 odd text_center">
				<a target="_blank" href="https://www.google.com/maps/place/EVedant+IITJEE/@28.630824,77.4318853,17z/data=!3m1!4b1!4m5!3m4!1s0x390cee3041ca8ca5:0x2971e199e5cca9fb!8m2!3d28.630824!4d77.434074">
				<span class="sc_icon icon-map-2 link_color font_5em lh_1em"></span>
				<div class="sc_section margin_top_1em_imp sc_features_st1">
					<p>
						306, Panchsheel Square Mall,<br>
						Crossings Republik, Ghaziabad
					</p>
				</div>
				</a>
			</div>
		</div>
	</div>
</div>