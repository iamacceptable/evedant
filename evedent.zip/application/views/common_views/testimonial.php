<div class="swiper-slide height_12em width_100per" data-style="width:100%;height:12em;">
	<div class="sc_testimonial_item">
		<div class="sc_testimonial_avatar">
			<img alt="" src="<?= base_url();?>assets/images/uploads/testimonial/<?= $testimonialDisplayPicture;?>"></div>
		<div class="sc_testimonial_content">
			<p><?= $testimonialMessage; ?></p>
		</div>
		<div class="sc_testimonial_author">
			<a><?= $testimonialName; ?></a>
			<br><a><?= $testimonialDesignation; ?></a>
		</div>
	</div>
</div>
