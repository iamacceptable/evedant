<figure class="sc_image  alignleft sc_image_shape_square margin_right_1_imp">
	<div class="isotope_item isotope_item_portfolio isotope_item_portfolio_2 isotope_column_2">
		<div class="post_item post_item_portfolio post_item_portfolio_2 odd">
			<div class="post_content isotope_item_content ih-item colored square effect8 scale_up">
				<div class="post_featured img margin_bottom_0_imp">
					<a>
						<img alt="" src="<?= base_url()."assets/images/uploads/toppers/".$starDisplayPicture; ?>">
						<!-- <img alt="" src="http://placehold.it/200x200"> -->
					</a>
				</div>
				<div class="post_info_wrap info">
					<div class="info-back">
						<h4 class="post_title">
							<a><?= $starName; ?></a>
						</h4>
						<div class="post_descr">
							<p>
								<a><?= $starClass;?></a><br>
								<a><?= str_replace("\n", "<br>", $starMarks); ?></a>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</figure>