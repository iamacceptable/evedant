<!-- bottomBar @graphicsByGolu -->
<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
		<span class="text-muted text-center text-sm-left d-block d-sm-inline-block"><a href="<?= base_url();?>" target="_blank">EVedant</a> © 2020 | All rights reserved | v3.0</span>
		<span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Designed and Developed with <i class="ti-heart text-danger"></i> by <a href="https://www.linkedin.com/in/iamacceptable">Shubham Kumar</a></span>
	</div>
</footer>