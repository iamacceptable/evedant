<div class="col-md-6 grid-margin stretch-card">
	<div class="card">
		<div class="card-body">
			<p class="card-title">Income/Expense Report</p>
			<p class="text-muted font-weight-light">Received overcame oh sensible so at an. Formed do change merely to county it. Am separate contempt domestic to to oh. On relation my so addition branched.</p>
			<div id="iEC-legend" class="chartjs-legend mt-4 mb-2"></div>
			<canvas id="incomeExpenseChart"></canvas>
		</div>
	</div>
</div>