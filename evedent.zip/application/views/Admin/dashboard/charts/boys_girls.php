<div class="col-md-6 grid-margin stretch-card">
	<div class="card border-bottom-0 pb-2">
		<div class="card-body pb-0">
			<p class="card-title">STUDENTS</p>
			<div class="d-flex flex-wrap mb-5">
				<div class="mr-5 mt-3">
					<p class="text-muted">Boys</p>
					<h3 class="counts-counter">362</h3>
				</div>
				<div class="mr-5 mt-3">
					<p class="text-muted">Girls</p>
					<h3 class="couts-counter">187</h3>
				</div>
			</div>
		</div>
		<canvas id="boysgirlsChart" width="798" height="399" class=""></canvas>
	</div>
</div>